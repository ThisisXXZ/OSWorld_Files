import random

choices = ["rock", "paper", "scissors"]

def determine_winner(player, computer):
    if player == computer:
        return "It's a tie!"
    elif (player == "rock" and computer == "scissors") or \
         (player == "scissors" and computer == "paper") or \
         (player == "paper" and computer == "rock"):
        return "You win!"
    else:
        return "Computer wins!"

if __name__ == "__main__":
    while True:
        print("\nOptions: rock, paper, scissors, or exit")
        player_choice = input("Enter your choice: ").strip().lower()

        if player_choice == "exit":
            print("Thanks for playing!")
            break
        elif player_choice not in choices:
            print("Invalid choice, try again.")
            continue

        computer_choice = random.choice(choices)
        print(f"Computer chose: {computer_choice}")
        print(determine_winner(player_choice, computer_choice))
