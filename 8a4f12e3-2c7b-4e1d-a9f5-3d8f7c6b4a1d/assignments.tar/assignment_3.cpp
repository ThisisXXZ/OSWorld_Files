#include <iostream>
#include <limits>

using namespace std;

class BankAccount {
private:
    string owner;
    double balance;

public:
    BankAccount(string name, double initialBalance) {
        owner = name;
        balance = initialBalance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposited: $" << amount << endl;
        } else {
            cout << "Invalid deposit amount!" << endl;
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: $" << amount << endl;
        } else {
            cout << "Insufficient funds or invalid amount!" << endl;
        }
    }

    void displayBalance() const {
        cout << owner << "'s Account Balance: $" << balance << endl;
    }
};

int main() {
    string name;
    double initialDeposit;

    cout << "Enter account holder's name: ";
    getline(cin, name);

    cout << "Enter initial deposit amount: $";
    while (!(cin >> initialDeposit) || initialDeposit < 0) {
        cout << "Invalid amount. Enter a positive number: $";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    BankAccount myAccount(name, initialDeposit);

    int choice;
    do {
        cout << "\nBank Menu:\n";
        cout << "1. Deposit Money\n";
        cout << "2. Withdraw Money\n";
        cout << "3. Check Balance\n";
        cout << "4. Exit\n";
        cout << "Choose an option: ";
        
        while (!(cin >> choice) || choice < 1 || choice > 4) {
            cout << "Invalid choice. Enter a number between 1 and 4: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (choice == 1) {
            double amount;
            cout << "Enter deposit amount: $";
            cin >> amount;
            myAccount.deposit(amount);
        } else if (choice == 2) {
            double amount;
            cout << "Enter withdrawal amount: $";
            cin >> amount;
            myAccount.withdraw(amount);
        } else if (choice == 3) {
            myAccount.displayBalance();
        }
    } while (choice != 4);

    cout << "Thank you for using our banking system!\n";
    return 0;
}
