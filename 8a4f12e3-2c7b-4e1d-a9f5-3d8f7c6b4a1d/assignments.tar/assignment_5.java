import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Student class
class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;
    private String studentID;

    // Constructor
    public Student(String name, int age, String studentID) {
        this.name = name;
        this.age = age;
        this.studentID = studentID;
    }

    // Display student details
    public void displayStudent() {
        System.out.println("Student ID: " + studentID);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("----------------------");
    }
}

// Main class
public class StudentManagement {
    private static final String FILE_NAME = "students.dat";
    private List<Student> students;
    
    public StudentManagement() {
        students = new ArrayList<>();
        loadStudents();
    }

    // Add a new student
    public void addStudent(String name, int age, String studentID) {
        Student newStudent = new Student(name, age, studentID);
        students.add(newStudent);
        saveStudents();
        System.out.println("Student added successfully!\n");
    }

    // Display all students
    public void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.\n");
            return;
        }
        System.out.println("Student List:");
        for (Student s : students) {
            s.displayStudent();
        }
    }

    // Save students to a file
    private void saveStudents() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(students);
        } catch (IOException e) {
            System.out.println("Error saving students: " + e.getMessage());
        }
    }

    // Load students from a file
    private void loadStudents() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            students = (List<Student>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous student records found.");
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManagement sm = new StudentManagement();

        while (true) {
            System.out.println("\nStudent Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Display Students");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Student Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Student ID: ");
                    String studentID = scanner.nextLine();
                    sm.addStudent(name, age, studentID);
                    break;
                case 2:
                    sm.displayStudents();
                    break;
                case 3:
                    System.out.println("Exiting program...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}
